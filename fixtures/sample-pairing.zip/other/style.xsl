<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="html"/>
  <xsl:template match="/"><html><head><title>フォルダ内唯一のXSL</title></head><body><h1 class="t">フォルダ内唯一のXSL</h1><p class="v"><xsl:value-of select="/R/V"/></p></body></html></xsl:template>
</xsl:stylesheet>
