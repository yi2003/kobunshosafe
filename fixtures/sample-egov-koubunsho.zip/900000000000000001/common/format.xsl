<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:template name="yen"><xsl:param name="v"/><xsl:value-of select="format-number($v, '#,##0')"/>円</xsl:template>
</xsl:stylesheet>
