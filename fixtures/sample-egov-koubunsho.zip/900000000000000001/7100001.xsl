<?xml version="1.0" encoding="Shift_JIS"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:include href="common/format.xsl"/>
  <xsl:output method="html" encoding="Shift_JIS"/>
  <xsl:template match="/DOC">
    <html><head><title><xsl:value-of select="HEAD/NAME"/>�i�T���v���j</title>
      <link rel="stylesheet" type="text/css" href="common/doc.css"/>
    </head><body>
      <h1 id="doc-title"><xsl:value-of select="HEAD/NAME"/></h1>
      <p>���Ə�����: <xsl:value-of select="HEAD/OFFICE"/>�@���Ə������L��: <xsl:value-of select="HEAD/OFFICE_NO"/></p>
      <table class="grid"><tr><th>�ԍ�</th><th>����</th><th>���i�擾�N����</th><th>��V���z</th></tr>
        <xsl:apply-templates select="ROW"/>
      </table>
      <p class="note">�� �O���͉摜�ŕ\��: <img class="gaiji" src="gaiji/G0001.png" alt="�O��"/></p>
    </body></html>
  </xsl:template>
  <xsl:template match="ROW">
    <tr><td><xsl:value-of select="NO"/></td>
      <td class="name"><xsl:value-of select="SHIMEI"/></td>
      <td><xsl:value-of select="DATE"/></td>
      <td class="num"><xsl:call-template name="yen"><xsl:with-param name="v" select="HOSHU"/></xsl:call-template></td></tr>
  </xsl:template>
</xsl:stylesheet>
