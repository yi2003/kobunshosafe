<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="html" encoding="UTF-8"/>
  <xsl:template match="/KAGAMI">
    <html><head><title><xsl:value-of select="TITLE"/></title>
      <style>body{font-family:serif;margin:2em} .r{text-align:right} h1{font-size:1.3em;text-align:center}</style>
    </head><body>
      <p class="r">到達番号 <span id="arrive"><xsl:value-of select="ARRIVE_ID"/></span><br/><xsl:value-of select="DATE"/></p>
      <p><xsl:value-of select="TO"/></p>
      <p class="r"><xsl:value-of select="FROM"/> <img src="images/seal.png" alt="公印" width="24" height="24"/></p>
      <h1><xsl:value-of select="TITLE"/></h1>
      <p id="kagami-body"><xsl:value-of select="BODY"/></p>
      <p>添付: <a href="{ATTACH/@href}"><xsl:value-of select="ATTACH"/></a></p>
    </body></html>
  </xsl:template>
</xsl:stylesheet>
